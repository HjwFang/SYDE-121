//*********************************************
// Student Name: Horst Fang
// Student Number: 21177922
//
// SYDE121 Lab: 01 Task: 01
//
// Filename: LAB 0101.cpp
// Date submitted: 9/15/2025
//
// I hereby declare that this code, submitted
// for credit for the course SYDE121, is a product
// of my own efforts. This coded solution has
// not been plagiarized from other sources and
// as not been knowingly plagiarized by others.
//
//*********************************************

#include <iostream>
using namespace std;

int main(){
    int i = 0;
    for (i = 3; i < 10; i++){
        cout << "i = " << i
        << " squared = "
        << i * i
        << endl;
    }
    cout << "\nA program by: Horst Fang\n";
    return 0;
}