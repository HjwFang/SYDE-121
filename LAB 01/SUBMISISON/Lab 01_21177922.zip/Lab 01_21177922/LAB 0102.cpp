//filename: lab0102.cpp

#include <iostream>
using namespace std;

int main(){
    int i = 0;
    for (i = 3; i <= 10; i++){
        cout << "i = " << i
        << " squared = "
        << i * i
        << endl;
    }
    cout << "\nFun!\n";
    return 0;
}