#ifndef large_sum_h
#define large_sum_h

#include <iostream>
#include <string>
using namespace std;

void enter_nums(string &num1, string &num2);

string add_large_numbers(string num1, string num2);

void display_num(string result);

#endif